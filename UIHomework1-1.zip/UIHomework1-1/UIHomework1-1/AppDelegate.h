//
//  AppDelegate.h
//  UIHomework1-1
//
//  Created by YaoxinZhuo on 5/8/16.
//  Copyright © 2016 YaoxinZhuo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

