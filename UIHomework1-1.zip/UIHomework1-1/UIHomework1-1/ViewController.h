//
//  ViewController.h
//  UIHomework1-1
//
//  Created by YaoxinZhuo on 5/8/16.
//  Copyright © 2016 YaoxinZhuo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

